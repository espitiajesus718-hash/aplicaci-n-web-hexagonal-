# Aplicación Web Hexagonal
Proyecto base con Backend y Frontend.
